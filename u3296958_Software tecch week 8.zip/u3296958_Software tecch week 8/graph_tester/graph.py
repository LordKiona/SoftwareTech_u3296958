class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}
        self.weights = {}
        self.directed = directed
        self.weighted = weighted
    def add_vertex(self, vertex):
        if vertex not in self.graph:
         self.graph[vertex] = []
    def add_edge(self, v1, v2, weight=0):
     if v1 in self.graph and v2 in self.graph:
        self.graph[v1].append(v2)

        if not self.directed:
            self.graph[v2].append(v1)
     def remove_edge(self, v1, v2):
        if v2 in self.graph[v1]:
           self.graph[v1].remove(v2)

    def remove_vertex(self, v):
        del self.graph[v]     
    def print_graph(self):
     for v in self.graph:
         print(v, "->", self.graph[v])






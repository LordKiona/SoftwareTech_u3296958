
from tkinter import *
import math

class KochSnowflake:
    def __init__(self):
        window = Tk()
        window.title("Koch Snowflake")

        self.width = 400
        self.height = 400
        self.canvas = Canvas(window, width=self.width, height=self.height)
        self.canvas.pack()

        frame1 = Frame(window)
        frame1.pack()

        Label(frame1, text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        Entry(frame1, textvariable=self.order, justify=RIGHT).pack(side=LEFT)
        Button(frame1, text="Display Koch Snowflake",
               command=self.display).pack(side=LEFT)

        window.mainloop()

    def display(self):
        self.canvas.delete("line")

        # Define an equilateral triangle
        p1 = (self.width/2, 20)
        p2 = (20, self.height - 20)
        p3 = (self.width - 20, self.height - 20)

        order = int(self.order.get())

        # Draw the three Koch sides
        self.koch(order, p1, p2)
        self.koch(order, p2, p3)
        self.koch(order, p3, p1)

    def koch(self, order, p1, p2):
        if order == 0:
            self.drawLine(p1, p2)
        else:
            # Compute the 1/3 and 2/3 points
            x1, y1 = p1
            x2, y2 = p2

            dx = (x2 - x1) / 3
            dy = (y2 - y1) / 3

            pA = (x1 + dx, y1 + dy)
            pB = (x1 + 2*dx, y1 + 2*dy)

            # Compute the peak of the equilateral triangle
            angle = math.radians(60)
            px = pA[0] + (dx * math.cos(angle) - dy * math.sin(angle))
            py = pA[1] + (dx * math.sin(angle) + dy * math.cos(angle))
            pC = (px, py)

            # Recursively draw the 4 segments
            self.koch(order - 1, p1, pA)
            self.koch(order - 1, pA, pC)
            self.koch(order - 1, pC, pB)
            self.koch(order - 1, pB, p2)

    def drawLine(self, p1, p2):
        self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags="line")

KochSnowflake()
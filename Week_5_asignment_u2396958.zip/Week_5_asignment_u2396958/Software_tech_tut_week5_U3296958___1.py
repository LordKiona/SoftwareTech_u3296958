count = 0  # global counter

def moveDisks(n, fromTower, toTower, auxTower):
    global count
    
    if n == 1:
        print("Move disk", n, "from", fromTower, "to", toTower)
        count += 1
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        
        print("Move disk", n, "from", fromTower, "to", toTower)
        count += 1
        
        moveDisks(n - 1, auxTower, toTower, fromTower)


def main():
    global count
    
    n = int(input("Enter number of disks: "))
    
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
    
    print("Total moves:", count)


main()